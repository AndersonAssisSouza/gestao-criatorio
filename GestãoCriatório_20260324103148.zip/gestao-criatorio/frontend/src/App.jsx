import { useState } from 'react'
import { AuthProvider, useAuth } from './context/AuthContext'
import { LoginPage }      from './components/auth/LoginPage'
import { Sidebar }        from './components/layout/Sidebar'
import { Topbar }         from './components/layout/Topbar'
import { PlantelModule }  from './components/modules/plantel/PlantelModule'
import { ComingSoon }     from './components/modules/ComingSoon'

const PAGE_TITLES = {
  plantel:    'Gestão do Plantel',
  chocando:   'Aves em Choco',
  gaiolas:    'Gestão das Gaiolas',
  filhotes:   'Filhotes Nascidos',
  especies:   'Espécies do Criatório',
  aviario:    'Gestão do Aviário',
  aneis:      'Controle de Anéis',
  financeiro: 'Gestão Financeira',
  explantel:  'Ex-Aves do Plantel',
  mutacoes:   'Simulação de Mutações',
}

function Dashboard() {
  const [page, setPage] = useState('plantel')

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#0A1A0C', fontFamily: "'DM Serif Display', serif" }}>
      <Sidebar activePage={page} onNavigate={setPage} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <Topbar page={page} />
        <div style={{ flex: 1, padding: 28, overflowY: 'auto', background: '#0A1A0C' }}>
          {page === 'plantel'
            ? <PlantelModule />
            : <ComingSoon module={PAGE_TITLES[page] || page} />
          }
        </div>
      </div>
    </div>
  )
}

function AppRouter() {
  const { isAuthenticated, loading } = useAuth()

  if (loading) return (
    <div style={{ minHeight: '100vh', background: '#0A1A0C', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#5A7A5C', fontFamily: "'DM Mono', monospace", fontSize: 13 }}>
      Carregando...
    </div>
  )

  return isAuthenticated ? <Dashboard /> : <LoginPage />
}

export default function App() {
  return (
    <AuthProvider>
      <AppRouter />
    </AuthProvider>
  )
}
